# wallstant-the-open-source-PHP-social-network
Create your own social network for free with Wallstant social network, easy to install and fast to use .. Make people connected

<h3>Official wallstant website</h3>
for more information about this open source PHP social network script : <br> 
<a href='https://wallstant.github.io/'>https://wallstant.github.io/</a>
<hr>
<h3 style="color: black;font-size: auto;">How to install</h3>
			<p style="color: gray">* When you <b>sign up</b> to the first time into your social network, you will be the main admin of website and you can add more admins from <b>Dashboard > users > Edit/Delete </b>.</p>
<ol type="1">
	<li>First of all, Download the script and extract it on your device.</li>
	<li>Open your <b>phpMyAdmin</b> and create new database and call it <b>wallstant</b>.</li>
	<li>Import <b>wallstant.sql</b> to your new database that you created, you can find <b>wallstant.sql</b> from wallstant folder that you extracted, in <b>database</b> folder.</li>
	<li>Edit <b>connect.php</b> file from <b>config &gt; connect.php</b>, set username and password and database name to your DB name ,pass and username.</li>
	<li>upload wallstant folder to your host.</li>
	<li>Enjoy it.</li>
</ol>
<hr>

## Contact me
[Instagram](https://instagram.com/munafio) <br>
[Facebook](https://facebook.com/munafio) <br>
[Twitter](https://twitter.com/munaf_aqeel_m) <br>
