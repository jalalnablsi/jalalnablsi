<?php
header("location: ../../index");

?>